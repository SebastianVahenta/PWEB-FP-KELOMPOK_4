// Constants
const ORG_NAME = 'PWEBC';
const BUCKET_NAME = 'IoT_Logger';
const API_TOKEN = 'KcX2ABqyknn3b4wPeV4_1cvhrmZZ3JyPjfWWSt_wl3q-6FWKD_DBtyhO8qU0ztHOccsD2m7Bq092dHwIkU_H_Q==';
const BASE_URL = 'http://localhost:8086/api/v2';

// Utility function to generate a random number within a range
function getRandomValue(min, max) {
    return Math.random() * (max - min) + min;
}

// Data Sensor (Randomized values within realistic ranges)
const sensorData = [
    { name: "Suhu", value: getRandomValue(20, 30), location: "Room1", data: Array.from({length: 5}, () => getRandomValue(20, 100)), backgroundColor: 'rgba(255, 99, 132, 0.2)', borderColor: 'rgba(255, 99, 132, 1)' },
    { name: "N", value: getRandomValue(10, 15), location: "Room1", data: Array.from({length: 5}, () => getRandomValue(10, 12)), backgroundColor: 'rgba(75, 192, 192, 0.2)', borderColor: 'rgba(75, 192, 192, 1)' },
    { name: "P", value: getRandomValue(3, 9), location: "Room1", data: Array.from({length: 5}, () => getRandomValue(3, 9)), backgroundColor: 'rgba(153, 102, 255, 0.2)', borderColor: 'rgba(153, 102, 255, 1)' },
    { name: "K", value: getRandomValue(2, 10), location: "Room1", data: Array.from({length: 5}, () => getRandomValue(2, 10)), backgroundColor: 'rgba(255, 159, 64, 0.2)', borderColor: 'rgba(255, 159, 64, 1)' },
    { name: "Ph", value: getRandomValue(6.0, 7.0), location: "Room1", data: Array.from({length: 5}, () => getRandomValue(6.0, 6.5)), backgroundColor: 'rgba(54, 162, 235, 0.2)', borderColor: 'rgba(54, 162, 235, 1)' },
    { name: "Kelembapan", value: getRandomValue(50, 60), location: "Room1", data: Array.from({length: 5}, () => getRandomValue(50, 56)), backgroundColor: 'rgba(255, 206, 86, 0.2)', borderColor: 'rgba(255, 206, 86, 1)' },
    { name: "Conductivity", value: getRandomValue(100, 120), location: "Room1", data: Array.from({length: 5}, () => getRandomValue(100, 110)), backgroundColor: 'rgba(75, 192, 192, 0.2)', borderColor: 'rgba(75, 192, 192, 1)' }
];

const timeLabels = ["10:00", "10:01", "10:02", "10:03", "10:04"];

// Function to Write Data to InfluxDB
function writeToInfluxDB(sensorType, location, value) {
    const url = `${BASE_URL}/write?org=${ORG_NAME}&bucket=${BUCKET_NAME}&precision=s`;
    const lineProtocol = `sensor_data,sensor="${sensorType}",location="${location}" value=${value}`;
    
    fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': `Token ${API_TOKEN}`,
            'Content-Type': 'text/plain'
        },
        body: lineProtocol
    })
    .then(response => {
        if (response.ok) {
            console.log(`Data for ${sensorType} written successfully!`);
        } else {
            console.error(`Failed to write data for ${sensorType}:`, response.statusText);
        }
    })
    .catch(error => console.error(`Error writing data for ${sensorType}:`, error));
}

// Function to Write All Data from sensorData to InfluxDB
function writeAllDataToInfluxDB() {
    sensorData.forEach(sensor => {
        writeToInfluxDB(sensor.name, sensor.location, sensor.value);
    });
}

// Function to Delete All Data from the Bucket
function deleteAllDataFromBucket() {
    const url = `${BASE_URL}/delete?org=${ORG_NAME}&bucket=${BUCKET_NAME}`;
    const body = JSON.stringify({
        start: '1970-01-01T00:00:00Z',
        stop: new Date().toISOString()  // Current time
    });

    fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': `Token ${API_TOKEN}`,
            'Content-Type': 'application/json'
        },
        body: body
    })
    .then(response => {
        if (response.ok) {
            console.log("All data deleted successfully from the bucket!");
            alert("All data has been successfully deleted from the bucket.");
        } else {
            console.error("Failed to delete data:", response.statusText);
            alert("Failed to delete data.");
        }
    })
    .catch(error => {
        console.error("Error deleting data:", error);
        alert("An error occurred while trying to delete data.");
    });
}

// Function to Create Sensor Card
function createSensorCard(sensor, index) {
    const cardContainer = document.createElement("div");
    cardContainer.className = "col-md-4 mb-3";
    cardContainer.innerHTML = `
        <div class="card shadow whitebg">
            <div class="card-body">
                <h5 class="card-title">${sensor.name}</h5>
                <p class="card-text">${sensor.value}</p>
                <canvas id="graph${sensor.name}${index}"></canvas>
            </div>
        </div>
    `;
    return cardContainer;
}

// Function to Create Chart
function createGraph(ctx, label, data, backgroundColor, borderColor) {
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                label: label,
                data: data,
                backgroundColor: backgroundColor,
                borderColor: borderColor,
                borderWidth: 2,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Initialize Sensor Cards within Accordion
function initializeSensors(containerId, index) {
    const sensorCardsContainer = document.getElementById(containerId);
    sensorData.forEach(sensor => {
        const sensorCard = createSensorCard(sensor, index);
        sensorCardsContainer.appendChild(sensorCard);

        const ctx = document.getElementById(`graph${sensor.name}${index}`).getContext("2d");
        createGraph(ctx, sensor.name, sensor.data, sensor.backgroundColor, sensor.borderColor);
    });
}

// Create Accordion Item
function createAccordionItem(title, containerId, index) {
    const accordionItem = document.createElement("div");
    accordionItem.className = "accordion-item";

    const expanded = index === 0 ? "true" : "false";
    const showClass = index === 0 ? "show" : "";

    accordionItem.innerHTML = `
        <h2 class="accordion-header" id="heading${index}">
            <button class="accordion-button shadow" type="button" data-bs-toggle="collapse" data-bs-target="#collapse${index}" aria-expanded="${expanded}" aria-controls="collapse${index}">
                ${title}
            </button>
        </h2>
        <div id="collapse${index}" class="accordion-collapse collapse ${showClass}" aria-labelledby="heading${index}" data-bs-parent="#sensorAccordion">
            <div class="accordion-body">
                <div class="container mt-4">
                    <div class="row" id="${containerId}">
                    </div>
                </div>
            </div>
        </div>
    `;
    return accordionItem;
}

// Initialize Accordion
function initializeAccordion() {
    const accordionContainer = document.getElementById("sensorAccordion");
    const accordionCount = 3;
    for (let i = 1; i <= accordionCount; i++) {
        const title = `IoT Logger - Sensor ${i}`;
        const containerId = `sensorCardsContainer${i}`;
        const accordionItem = createAccordionItem(title, containerId, i);
        accordionContainer.appendChild(accordionItem);
        initializeSensors(containerId, i);
    }
}

// Start the Application
initializeAccordion();
writeAllDataToInfluxDB(); // Automatically writes all data to InfluxDB on page load
